
var app = angular.module('myApp', ['ngWebSocket']);

app.controller('MyController', function($scope, MyData) {


  $scope.MyData = MyData;

    
    $scope.username = 'anonymous';
    
      $scope.submit = function(new_message) {
        if (!new_message) { return; }
        MyData.send({
          username: $scope.username,
          message: new_message
        });
        $scope.new_message = '';
      };
    



  /*var res = [];
  for (var x in MyData){
    MyData.hasOwnProperty(x) && res.push(MyData[x])
   
  }*/
  
  
  $scope.eventList = {

      date : 'Thursday Oct, 12 2017',

      asignedtask:[
          {
            title: 'Just Now',
            content: "Oliver Quiver has signed the interview-Book Travel task to you..",
          },
          {
            title: 'Just Now',
            content: "Oliver Quiver has signed the interview-Book Travel task to you..",
          },
          {
            title: 'Just Now',
            content: "Oliver Quiver has signed the interview-Book Travel task to you..",
          },    
      ],
      reminder:[
        {
          title: 'Just Now',
          content: "Oliver Quiver has signed the interview-Book Travel task to you.."
        },    
     ],

     notifications:[
      {
        title: 'Yesterday',
        content: "Sarah Guitienez has completed the questionnaire agianst your UX desinger Requistion"
      },    
     ]
    }

});


app.factory('MyData', function($websocket) {
  
  var ws = $websocket('ws://localhost:8080');

  var collection = [];
  
    ws.onMessage(function(event) {
      console.log('message:', event);
      var res;
      try {
        res = JSON.parse(event.data);
      } catch(e) {
        res = {'username': 'anonymous', 'message': event.data};
      }
  
      collection.push({
        username: res.username,
        content: res.message,
        timeStamp: event.timeStamp
      });
    });
  
    ws.onError(function(event) {
      console.log('connection Error', event);
    });
  
    ws.onClose(function(event) {
      console.log('connection closed', event);
    });
  
    ws.onOpen(function() {
      console.log('connection open');
      ws.send('Hello World');
      ws.send('again');
      ws.send('and again');
    });

    return {
      collection: collection,
      status: function() {
        return ws.readyState;
      },
      send: function(message) {
        if (angular.isString(message)) {
          ws.send(message);
        }
        else if (angular.isObject(message)) {
          ws.send(JSON.stringify(message));
        }
      }
  
    };
})





app.directive('notifications', function() {
	  
    return {
      restrict: 'EA',
      transclude: true,
      templateUrl: '../pages/template.html',
      scope: {
        eventInfo : "=info"
      },
      link: function(scope, element, attrs, controller) {
        
        /*scope.viewModel = {
          showTemplateA: false,
          showTemplateB: false
        };
        
        scope.toggleTemplateA = function () {

          scope.viewModel.showTemplateA = !scope.viewModel.showTemplateA;
          
          scope.viewModel.showTemplateB = false;          
        };
        
        scope.toggleTemplateB = function () {
          
          scope.viewModel.showTemplateB = !scope.viewModel.showTemplateB;
          
          scope.viewModel.showTemplateA = false;
        };*/

      }
    };
  });
