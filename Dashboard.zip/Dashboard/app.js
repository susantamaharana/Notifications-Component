var http = require('http');
var fs = require('fs');

var server = http.createServer(function(req, res){
  console.log('request was made: '+ req.url);
  res.writeHead(200, {'Content-type': 'application/json'});
  var myObj = {
    name:'susanta',
    job:'software deverloper',
    age:35
  }
  res.end(JSON.stringify(myObj));
})

server.listen(3000, 8081);
console.log('you dawgs, now listening to port 3000')