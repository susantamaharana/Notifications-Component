
const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8080 });


wss.on('connection', function connection(ws) {
  console.log('connection established');
  
 setInterval(function(){
    wss.clients.forEach(function each(client) {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send('hello from server' + client);
      }
    });
    
  },1000);
  console.log('sending');
});


/*var http = require('http');

var app = http.createServer(function(req,res){
    res.setHeader('Content-Type', 'application/json');
    res.send(JSON.stringify({ a: 1 }, null, 3));
});
app.listen(8080);*/

/*var WebSocket = require('ws');
var http = require('http');

var server = http.createServer();
server.addListener('upgrade', function(request, socket, head) {
    var ws = new WebSocket(request, socket, head);

    var object = {topic:'handshake', data:'sdf487rgiuh7'}
    ws.send(JSON.stringify(object));
});
server.listen(8080);*/


