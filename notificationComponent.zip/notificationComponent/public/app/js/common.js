$(document).ready(function() {
  $('.dropdown-menu').click(function(e) {
    e.stopPropagation();
  });
});

