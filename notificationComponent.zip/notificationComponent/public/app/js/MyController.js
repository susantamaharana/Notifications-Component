
var app = angular.module('myApp', []);

app.controller('MyController', function ($scope, $http) {

  $scope.events = { message: [] };

  $scope.asignCount = 0;
  $scope.remidCount = 0;
  $scope.notifyCount = 0;

  $scope.formatDate = function (date) {
    $scope.monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    $scope.weekday = ["Sunday","Monday","Tuesday", "Wednesday","Thursday","Friday","Saturday"];
    $scope.day = date.getDate();
    $scope.monthIndex = date.getMonth();
    $scope.year = date.getFullYear();
    $scope.d = new Date();
    $scope.n = $scope.weekday[$scope.d.getDay()];
    //Monday Sept 12, 2016
    return $scope.n + ' ' +$scope.monthNames[$scope.monthIndex] + ' ' + $scope.day + ', ' + $scope.year;
  }

  $scope.currentDate = $scope.formatDate(new Date());

  $scope.openPoupup = function () {
    $http.get("/api/users")
      .then(function (response) {
        $scope.getBindtoNotify(Object.values(response.data));
      });
  }

  $scope.getBindtoNotify = function (res) {
    $scope.viewEventList = { message: [] };
    $scope.msgCount = [];

    var obj = {};

    for (var i = 0; i < res.length; i++) {
      for (var j = 0; j < res[i].message.length; j++) {
        obj = { date: res[i].message[j].date, content: res[i].message[j].content, title: res[i].message[j].title }
        $scope.viewEventList.message.unshift(obj);
        $scope.msgCount.push(obj.title)
      }
    }
    $scope.count($scope.msgCount)
    
  }

  $scope.SendData = function (id, msge) {
    var obj = {};
    switch (id) {
      case 'asigntask':
        obj = { date: $scope.currentDate, content: msge, title: 'asigned' }
        $scope.events.message.push(obj);
        break;
      case 'reminder':
        obj = { date: $scope.currentDate, content: msge, title: 'reminder' }
        $scope.events.message.push(obj)
        break;
      case 'notification':
        obj = { date: $scope.currentDate, content: msge, title: 'notification' }
        $scope.events.message.push(obj)
        break;
    }

    var data = obj;
    $http.post('/api/insert', data)
      .success(function (data) {
        $scope.PostDataResponse = data;
        console.log(data);
      })
  };


 $scope.count = function(arr){
      array_elements = arr;
  
      array_elements.sort();
  
      var current = null;
      var cnt = 0;
      for (var i = 0; i < array_elements.length; i++) {
          if (array_elements[i] != current) {
              if (cnt > 0) {
                  if(current == 'asigned'){
                    $scope.asignCount = cnt;
                  }else if(current == 'notification'){
                    $scope.notifyCount = cnt;
                  }else if(current == 'reminder'){
                    $scope.remidCount = cnt;
                  }
                  //console.log(current + ' comes --> ' + cnt + ' times<br>');
              }
              current = array_elements[i];
              cnt = 1;
          } else {
              cnt++;
          }
      }
      if (cnt > 0) {
          if(current == 'asigned'){
            $scope.asignCount = cnt;
          }else if(current == 'notification'){
            $scope.notifyCount = cnt;
          }else if(current == 'reminder'){
            $scope.remidCount = cnt;
          }
          //console.log(current + ' comes --> ' + cnt + ' times');
      }
 }
 
  //$scope.MyData = MyData;
  /*var res = [];
  for (var x in MyData){
    MyData.hasOwnProperty(x) && res.push(MyData[x])
  }*/

});


/*app.factory('MyData', function($websocket) {
 
  var dataStream = $websocket('ws://localhost:3000');

  var collection = [];

  dataStream.onMessage(function(message) {
    collection.push(JSON.parse(message.data));
  });

  var methods = {
    collection: collection,
    get: function() {
      dataStream.send(JSON.stringify(
        {
          name: 'susanta',
          username: 'maharana'
        }
      ));
    }
  };

  return methods;
})*/









