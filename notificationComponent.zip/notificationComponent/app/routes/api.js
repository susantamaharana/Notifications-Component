var User = require('../models/user');
var config = require('../../config');
var secretKey = config.secretKey;

module.exports = function (app, express) {

    var api = express.Router();

    api.post('/insert', function (req, res) {

        //message : [{date:String, content: String, title:String}]

        var user = new User({
            message: [
                { date: req.body.date, content: req.body.content, title: req.body.title }
            ]

        });

        /*var user = new User({
            asigntask: req.body.asigntask,
            reminder: req.body.reminder,
            notification: req.body.notification
        });*/

        user.save(function (err) {
            if (err) {
                res.send(err);
                return;
            }
            res.json({ message: 'message has been created!' })
        });
    })

    api.get('/users', function (req, res) {
        User.find({}, function (err, users) {
            if (err) {
                res.send(err);
                return;
            }
            res.json(users)
        })
    })

    return api;
}


