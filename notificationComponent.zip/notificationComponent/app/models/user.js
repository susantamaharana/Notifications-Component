var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var bcrypt = require('bcrypt-nodejs');

var UserSchema = new Schema({
    message : [{date:String, content: String, title:String}]

    });
    
module.exports = mongoose.model('User', UserSchema);

/*{
    asigntask:String,
    reminder:String,
    notifiction:String
}*/