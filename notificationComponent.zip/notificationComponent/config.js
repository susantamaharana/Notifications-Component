module.exports = {
    "database":"mongodb://localhost:27001/notify",
    "port": process.env.PORT || 3000
}